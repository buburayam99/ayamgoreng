* Go to Helpdesk
* Create or select a ticket
* Create an FSM Order

To close a ticket, all the related service orders must be closed.
