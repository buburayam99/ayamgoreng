This module links Field Service, Agreements and Help Desk together by:

* setting the agreement fields when creating Field Service orders from a ticket.
