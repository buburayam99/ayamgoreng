With the Field Service App, building out a site like an apartment complex 
with multiple buildings, floors, units can become cumbersome and 
tedious to build all the records. Even building an importable spreadsheet 
can be tedious to build, and new users will struggle with this.

This module is for organizations that needs to create the locations 
structure (~100 sub-locations) of a new site in less than a minute. 
It provides a wizard on a location that will assist in building the 
sub-location hierarchy.
