To use this module, you need to:

* Go to Contacts > Relation Types
* Create or select a relation type with FSM location
* Choose wether or not make it a unique relation
