To use this module, you need to:

* Go to Field Service > Master Data > Equipments or Maintenance > Equipments
* Create or select an equipment
* Specify the maintenance schedule
