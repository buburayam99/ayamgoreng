Odoo Maintenance App does not support Field Service operations for equipments
outside the company facilities. On the other hand, the Field Service App does
not support a maintenance schedule generating preventive maintenance request.

This module allows you to merge equipments from Field Service and Maintenance
and have a maintenance schedule for FSM equipments as well as Field Service
capabilities for maintenance equipments.
