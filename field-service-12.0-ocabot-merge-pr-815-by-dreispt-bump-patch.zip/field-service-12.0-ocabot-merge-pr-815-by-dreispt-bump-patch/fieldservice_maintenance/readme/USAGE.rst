To use this module, you need to:

* Maintenance requests related to a FSM equipment will create a FSM order
* Go to Field Service
* Create or select a FSM order and select the type Maintenance.
* Select the maintenance team, the equipment and the location
* Upon saving, a maintenance request will be created with the information from the FSM order.
