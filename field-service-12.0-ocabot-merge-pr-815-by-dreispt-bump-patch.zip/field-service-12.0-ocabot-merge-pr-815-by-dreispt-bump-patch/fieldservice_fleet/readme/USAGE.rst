To use this module, you need to:

Fleet

    * Go to Fleet
    * Create or select a vehicle
    * From Action menu, choose Convert to FSM Vehicle
    * A new FSM Vehicle will be created linked to this Fleet Vehicle

Field Service

    * Go to Field Service > Master Data > Vehicles
    * Select or create a vehicle.
    * Link to a Fleet Vehicle by assigining one to the vehicle details

Changing the Fleet vehicle driver sets the FSM Vehicle worker
Changing the FSM Vehicle worker sets the Fleet Vehicle driver
