This module allows you to link the vehicles and workers of Field Service with vehicles and drivers of Fleet.

Beware that the Fleet module can have more vehicles than the FSM one (not all vehicles of the company are used for Field Service work).
