To use this module, you need to:

* Go to Field Service
* Select or create a Field Service order
* Click on the "Register Payment" button
* Select the Payment Method
* Enter the amount
* Validate
