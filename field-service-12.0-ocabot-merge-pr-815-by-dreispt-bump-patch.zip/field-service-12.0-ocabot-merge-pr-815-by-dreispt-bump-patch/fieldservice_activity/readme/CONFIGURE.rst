To use this module, you need to:

* Go to Field Service > Settings > Manage Activites
