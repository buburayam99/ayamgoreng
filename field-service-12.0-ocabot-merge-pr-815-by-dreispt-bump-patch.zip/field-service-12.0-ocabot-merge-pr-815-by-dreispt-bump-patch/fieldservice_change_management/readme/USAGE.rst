To use this module, you need to:

* Open a FSM Location
* Click on ‘Change Log’ smart button
* Create or view Change Logs
* You can print change logs from the location, location list or change log list.
* Users with Change Log Manager access will have access to all change logs via the menu on the main dashboard.
