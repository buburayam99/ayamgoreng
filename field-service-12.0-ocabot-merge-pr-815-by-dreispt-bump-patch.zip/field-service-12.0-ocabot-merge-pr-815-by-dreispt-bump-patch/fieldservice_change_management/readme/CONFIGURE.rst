Users with Change Log Manager access can configure via the Configuration Menu in the Change Log app.
* Open the Change Logs app.
* Go to Configuration menu.
* Configure Stages, Tags, Types, and Impacts according to your needs.
