This is a bridge module between Management System and Field Service

This module contains some new features for Management System modules.

Nonconformity (NC)

- FSM Order: add a field to link a specific FSM Order.
