This module adds the ability to link field service orders to invoices.
