To use this module, you need to:

* User must have Field Service User permissions or higher.
* Go to Project or Project Task
* Create Field Service Order from Service Orders notebook tab.
