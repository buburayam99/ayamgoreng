To configure this module, you need to:

* Go to Field Service > Master Data > Locations
* Create or select a location and set their analytic account
