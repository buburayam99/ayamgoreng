To configure this module, you need to:

* Go to Field Service > Configuration > Stages

You need to select Choose Color to display color icon in map view.
