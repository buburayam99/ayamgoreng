To use this module, you need to:

* Go to Field Service > Master Data > Locations
* Create or select a location
* In the "Others" tab, you can set a location as a distribution location
* On another location, below the Parent location, you can set the parent
  distribution location that distributes to the current location
