This module displays map views on the order and location using the GeoEngine module and PostGIS.
