To configure this module, you need to:

* Go to Inventory > Configuration > Delivery Methods
* Review the existing delivery methods or create new ones
