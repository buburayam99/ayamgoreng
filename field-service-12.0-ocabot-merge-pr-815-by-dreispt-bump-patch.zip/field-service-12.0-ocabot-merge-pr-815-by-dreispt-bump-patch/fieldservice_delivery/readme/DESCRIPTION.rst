This module is an add-on for the Field Service application in Odoo.
It provides delivery capabilities on the field service orders.
