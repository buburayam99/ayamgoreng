This module displays map views on the order and location using Google Map View module.
