Please refer to the installation instructions available at:

https://github.com/OCA/geospatial/tree/12.0/base_google_map
https://github.com/OCA/geospatial/tree/12.0/web_view_google_map
