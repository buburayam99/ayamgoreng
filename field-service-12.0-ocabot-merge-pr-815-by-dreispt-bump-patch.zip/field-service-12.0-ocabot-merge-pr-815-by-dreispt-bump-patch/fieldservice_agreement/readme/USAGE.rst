To use this module:

* Go to Field Service > Operations > Orders
* Select or create a field service order and set the agreement
* Go to Agreement > Agreements
* Open the previous agreement
* Click on the smart button "Service Orders" to see the list of related field service orders
