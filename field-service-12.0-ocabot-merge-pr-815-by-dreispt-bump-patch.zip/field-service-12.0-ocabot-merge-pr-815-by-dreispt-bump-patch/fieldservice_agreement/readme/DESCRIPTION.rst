Odoo Agreement App does not provide an easy way to access field service orders
related to an agreement. Some organizations needs to have a quick access to
field service orders to track the performance of an agreement.

This module allows you to link a field service order to an agreement and adds a
smart button on the agreement to look at the list of related field service
orders.
